# MediaElementPlayer-exmaple
## Description
...
## About
[**Code UP**](https://quera.ir/codeup/) is an open-source hackathon hosted quarterly. By making interesting open-source tools in our events, we intend to build a better web together, and empower Iran developer community.

Code Up is hosted by [**Quera**](https://quera.ir), an online community for developers in Iran. The theme for our first event is  “online video player” and it's sponsored by [**Dideo**](https://www.dideo.ir/), a video meta-search engine.

Best answers:

+ ...
